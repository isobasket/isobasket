import { login, signup, logout, getUser, handleAuthCallback, AuthError, MissingIdentityError } from 'https://esm.sh/@netlify/identity@2.0.0';

const $ = id => document.getElementById(id);
let settings = { date: '', venue: '', fee: '', prize: '', results: [] };
let creating = false;

function node(tag, value) { const n = document.createElement(tag); n.textContent = value ?? ''; return n; }
async function api(path, options = {}) {
  const res = await fetch(path, { credentials: 'same-origin', ...options, headers: { 'Content-Type': 'application/json', ...options.headers } });
  let data = null; try { data = await res.json(); } catch {}
  if (!res.ok) { const e = Error(data?.error || 'Request failed'); e.status = res.status; throw e; }
  return data;
}
const authStatus = m => { $('authStatus').textContent = m; };
const status = m => { $('status').textContent = m; };
function authMessage(error) {
  if (error instanceof MissingIdentityError) return 'Sign-in is not switched on for this site yet.';
  if (error instanceof AuthError) {
    if (error.status === 400 || error.status === 401) return /confirm/i.test(error.message) ? 'Please confirm your email first — check your inbox.' : 'Wrong email or password.';
    if (error.status === 422) return creating ? 'An account with this email may already exist — try signing in.' : error.message;
    return error.message;
  }
  return error?.message || 'Something went wrong.';
}

function setMode(create) {
  creating = create;
  $('authButton').textContent = create ? 'Create account' : 'Sign in';
  $('password').autocomplete = create ? 'new-password' : 'current-password';
  $('modeHint').textContent = create ? 'Use your organizer email and choose a password (at least 8 characters).' : 'Organizers only.';
  $('toggleMode').textContent = create ? 'Already have an account? Sign in' : 'First time? Create your organizer account';
  authStatus('');
}
$('toggleMode').onclick = () => setMode(!creating);

function showDashboard(on) { $('signin').hidden = on; $('dashboard').hidden = !on; $('top').hidden = !on; }

async function openDashboard() {
  try {
    await api('/api/me');
  } catch (error) {
    showDashboard(false);
    if (error.status === 403) { try { await logout(); } catch {} authStatus('This account is not an organizer.'); }
    else if (error.status !== 401) authStatus(error.message);
    return;
  }
  showDashboard(true);
  await Promise.all([loadPlayers(), loadSettings()]).catch(e => status(e.message));
}

$('authForm').onsubmit = async e => {
  e.preventDefault();
  const email = $('email').value.trim(), password = $('password').value;
  $('authButton').disabled = true;
  try {
    if (creating) {
      const user = await signup(email, password);
      if (!user.emailVerified) { setMode(false); authStatus('Account created. Open the confirmation email we just sent you — it brings you back here signed in.'); return; }
    } else {
      await login(email, password);
    }
    $('password').value = '';
    await openDashboard();
  } catch (error) { authStatus(authMessage(error)); }
  finally { $('authButton').disabled = false; }
};

$('logout').onclick = async () => { try { await logout(); } catch {} $('players').replaceChildren(); showDashboard(false); authStatus('Signed out.'); };

async function loadPlayers() {
  const rows = await api('/api/players');
  summary(rows);
  if (!rows.length) { const tr = node('tr'); const td = node('td', 'No registrations yet.'); td.colSpan = 11; tr.append(td); $('players').replaceChildren(tr); return; }
  $('players').replaceChildren(...rows.map(r => {
    const tr = node('tr');
    const wa = node('td'); const waLink = node('a', r.phone); waLink.href = 'https://wa.me/' + String(r.phone).replace(/\D/g, ''); waLink.target = '_blank'; waLink.rel = 'noopener noreferrer'; wa.append(waLink);
    const hl = node('td'); if (/^https:\/\//i.test(r.highlights || '')) { const a = node('a', 'View'); a.href = r.highlights; a.target = '_blank'; a.rel = 'noopener noreferrer'; hl.append(a); }
    const del = node('td'); const b = node('button', 'Remove'); b.type = 'button';
    b.onclick = async () => { if (!confirm('Remove ' + r.name + ' from the list?')) return; try { await api('/api/players?id=' + r.id, { method: 'DELETE' }); await loadPlayers(); status('Removed ' + r.name + '.'); } catch (e) { status(e.message); } };
    del.append(b);
    tr.append(node('td', r.name), node('td', r.age), node('td', r.city), wa, node('td', r.height ?? ''), node('td', r.style), node('td', r.social), node('td', r.source || ''), hl, paidCell(r, rows), node('td', new Date(r.createdAt).toLocaleString()), del);
    return tr;
  }));
}
function summary(rows) {
  const confirmed = rows.filter(r => r.paid).length;
  $('count').textContent = '(' + rows.length + ')';
  $('confirmSummary').textContent = confirmed + ' confirmed · ' + (rows.length - confirmed) + ' waiting for payment · ' + Math.max(0, 32 - confirmed) + ' of 32 spots left';
}
function confirmText(r) {
  return 'isobasket – Hi ' + r.name + ', we received your entry fee. Your place in the Riyadh 1v1 tournament is confirmed ✅\n' +
    'مرحباً ' + r.name + '، استلمنا رسوم المشاركة. تم تأكيد مقعدك في البطولة ✅';
}
function paidCell(r, rows) {
  const td = node('td'); td.style.whiteSpace = 'nowrap';
  const draw = () => {
    const b = node('button', r.paid ? '✓ Confirmed' : 'Confirm payment'); b.type = 'button';
    b.className = r.paid ? 'confirmed' : 'pending';
    b.title = r.paid ? 'Click to undo the confirmation' : 'Mark ' + r.name + ' as paid and hold their spot';
    b.onclick = async () => {
      const next = !r.paid;
      if (!next && !confirm('Undo the payment confirmation for ' + r.name + '? Their spot will be released.')) return;
      b.disabled = true;
      try {
        await api('/api/players?id=' + r.id, { method: 'PATCH', body: JSON.stringify({ paid: next }) });
        r.paid = next; summary(rows); draw();
        status(next ? r.name + ' is confirmed. Their spot is now held.' : r.name + ' is back to waiting for payment.');
      } catch (e) { status(e.message); b.disabled = false; }
    };
    const parts = [b];
    if (r.paid) { const w = node('a', 'Tell them on WhatsApp'); w.className = 'tell'; w.target = '_blank'; w.rel = 'noopener noreferrer'; w.href = 'https://wa.me/' + String(r.phone).replace(/\D/g, '') + '?text=' + encodeURIComponent(confirmText(r)); parts.push(w); }
    td.replaceChildren(...parts);
  };
  draw(); return td;
}
$('refresh').onclick = () => loadPlayers().then(() => status('Player list updated.')).catch(e => status(e.message));

async function loadSettings() {
  settings = { ...settings, ...(await api('/api/tournament')) };
  $('dateSetting').value = settings.date || ''; $('venueSetting').value = settings.venue || ''; $('feeSetting').value = settings.fee || ''; $('prizeSetting').value = settings.prize || ''; $('bankHolderSetting').value = settings.bankHolder || ''; $('barqIbanSetting').value = settings.barqIban || ''; $('stcIbanSetting').value = settings.stcIban || '';
  $('resultsInput').value = (settings.results || []).map(r => [r.round, r.a, r.b, r.score].join(' | ')).join('\n');
}
async function publish(next) { settings = await api('/api/tournament', { method: 'PUT', body: JSON.stringify(next) }); status('Saved. The player page now shows this.'); }
const ibanOk = v => !v.trim() || /^SA\d{22}$/i.test(v.replace(/\s+/g, ''));
$('settingsForm').onsubmit = async e => { e.preventDefault(); if (!ibanOk($('barqIbanSetting').value) || !ibanOk($('stcIbanSetting').value)) { status('An IBAN looks wrong. Saudi IBANs start with SA followed by 22 digits.'); return; } try { await publish({ ...settings, date: $('dateSetting').value, venue: $('venueSetting').value, fee: $('feeSetting').value, bankHolder: $('bankHolderSetting').value, barqIban: $('barqIbanSetting').value, stcIban: $('stcIbanSetting').value, prize: $('prizeSetting').value }); } catch (err) { status(err.message); } };
$('resultsForm').onsubmit = async e => {
  e.preventDefault();
  try {
    const results = $('resultsInput').value.split('\n').filter(l => l.trim()).map(line => {
      const p = line.split('|').map(s => s.trim());
      if (p.length !== 4 || p.some(x => !x)) throw Error('Each line needs four parts separated by |');
      return { round: p[0], a: p[1], b: p[2], score: p[3] };
    });
    await publish({ ...settings, results });
  } catch (err) { status(err.message); }
};

(async () => {
  try {
    const result = await handleAuthCallback();
    if (result?.type === 'confirmation') authStatus('Email confirmed.');
  } catch (error) { authStatus(authMessage(error)); }
  if (await getUser()) await openDashboard();
})();

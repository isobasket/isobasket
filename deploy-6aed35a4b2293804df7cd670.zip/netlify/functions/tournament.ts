import type { Config } from "@netlify/functions";
import { eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { tournament } from "../../db/schema.js";
import { requireOrganizer, sameOrigin } from "../lib/organizer.js";

const str = (v: unknown, max: number) => (typeof v === "string" ? v.trim().slice(0, max) : "");

// Saudi IBAN: SA + 22 digits. Spaces are allowed when typing and removed here.
function iban(v: unknown) {
  const s = str(v, 40).replace(/\s+/g, "").toUpperCase();
  return /^SA\d{22}$/.test(s) ? s : "";
}

export default async (req: Request) => {
  if (req.method === "GET") {
    const [row] = await db.select().from(tournament).where(eq(tournament.id, 1));
    return Response.json(row?.content ?? {}, { headers: { "Cache-Control": "no-store" } });
  }

  if (!sameOrigin(req)) return Response.json({ error: "Forbidden" }, { status: 403 });
  const auth = await requireOrganizer();
  if (auth.error) return auth.error;

  let body: Record<string, unknown>;
  try {
    body = await req.json();
  } catch {
    return Response.json({ error: "Invalid request" }, { status: 400 });
  }
  const results = Array.isArray(body.results) ? body.results.slice(0, 64) : [];
  const content = {
    date: str(body.date, 160),
    venue: str(body.venue, 160),
    fee: str(body.fee, 80),
    bankHolder: str(body.bankHolder, 100),
    barqIban: iban(body.barqIban),
    stcIban: iban(body.stcIban),
    prize: str(body.prize, 400),
    results: results.map((r: Record<string, unknown>) => ({
      round: str(r?.round, 80),
      a: str(r?.a, 80),
      b: str(r?.b, 80),
      score: str(r?.score, 40),
    })).filter((r) => r.round && r.a && r.b && r.score),
  };

  await db
    .insert(tournament)
    .values({ id: 1, content })
    .onConflictDoUpdate({ target: tournament.id, set: { content, updatedAt: new Date() } });
  return Response.json(content);
};

export const config: Config = { path: "/api/tournament", method: ["GET", "PUT"] };

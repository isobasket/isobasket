import type { Config } from "@netlify/functions";
import { count, eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { registrations } from "../../db/schema.js";

const TOTAL = 32;

// Public: only the number of registrations, never any player details.
export default async () => {
  const [[all], [paid]] = await Promise.all([
    db.select({ n: count() }).from(registrations),
    db.select({ n: count() }).from(registrations).where(eq(registrations.paid, true)),
  ]);
  // A spot is only held once the organizer has confirmed the player's payment.
  return Response.json(
    { registered: Number(all?.n ?? 0), confirmed: Number(paid?.n ?? 0), total: TOTAL },
    { headers: { "Cache-Control": "public, max-age=0, must-revalidate", "Netlify-CDN-Cache-Control": "public, max-age=30, stale-while-revalidate=60" } },
  );
};

export const config: Config = { path: "/api/spots", method: "GET" };

import type { Config } from "@netlify/functions";
import { requireOrganizer } from "../lib/organizer.js";

export default async () => {
  const auth = await requireOrganizer();
  if (auth.error) return auth.error;
  return Response.json({ email: auth.user.email }, { headers: { "Cache-Control": "no-store" } });
};

export const config: Config = { path: "/api/me", method: "GET" };

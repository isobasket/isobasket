import type { Config } from "@netlify/functions";
import { desc, eq } from "drizzle-orm";
import { db } from "../../db/index.js";
import { registrations } from "../../db/schema.js";
import { requireOrganizer, sameOrigin } from "../lib/organizer.js";

export default async (req: Request) => {
  const auth = await requireOrganizer();
  if (auth.error) return auth.error;

  if (req.method === "PATCH") {
    if (!sameOrigin(req)) return Response.json({ error: "Forbidden" }, { status: 403 });
    const id = Number(new URL(req.url).searchParams.get("id"));
    if (!Number.isInteger(id)) return Response.json({ error: "Invalid id" }, { status: 400 });
    let body: Record<string, unknown>;
    try { body = await req.json(); } catch { return Response.json({ error: "Invalid request" }, { status: 400 }); }
    if (typeof body.paid !== "boolean") return Response.json({ error: "Invalid request" }, { status: 400 });
    await db.update(registrations).set({ paid: body.paid }).where(eq(registrations.id, id));
    return Response.json({ ok: true });
  }

  if (req.method === "DELETE") {
    if (!sameOrigin(req)) return Response.json({ error: "Forbidden" }, { status: 403 });
    const id = Number(new URL(req.url).searchParams.get("id"));
    if (!Number.isInteger(id)) return Response.json({ error: "Invalid id" }, { status: 400 });
    await db.delete(registrations).where(eq(registrations.id, id));
    return Response.json({ ok: true });
  }

  const rows = await db.select().from(registrations).orderBy(desc(registrations.createdAt));
  return Response.json(rows, { headers: { "Cache-Control": "no-store" } });
};

export const config: Config = { path: "/api/players", method: ["GET", "PATCH", "DELETE"] };
